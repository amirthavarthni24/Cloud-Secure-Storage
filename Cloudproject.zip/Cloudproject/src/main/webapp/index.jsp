<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Cloud Project</title>
</head>
<body>

<h1>Cloud Based Archive System</h1>
<p>Module 1 : User Interface</p>
<p>This page is the entry point of the application.</p>

</body>
</html>
    