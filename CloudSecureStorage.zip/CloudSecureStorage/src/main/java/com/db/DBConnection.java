package com.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() {
        Connection con = null;
        try {
            System.out.println("Loading Driver...");
            Class.forName("oracle.jdbc.driver.OracleDriver");

            System.out.println("Connecting to DB...");
            con = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:XE",
                "clouduser",
                "cloud123"
            );

            System.out.println("Connection SUCCESS");

        } catch (Exception e) {
            System.out.println("Connection ERROR:");
            e.printStackTrace();   // 👈 MOST IMPORTANT
        }
        return con;
    }
}

