package com.servlet;

import com.db.DBConnection;
import com.security.AESUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/UploadServlet")
@MultipartConfig
public class UploadServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String user = (String) session.getAttribute("user");

        Part filePart = request.getPart("file");
        String fileName = filePart.getSubmittedFileName();
        String fileNameLower = fileName.toLowerCase();

        if (!(fileNameLower.endsWith(".jpg")
        		   || fileNameLower.endsWith(".zip")
        		   || fileNameLower.endsWith(".doc")
        		   || fileNameLower.endsWith(".webp")
        		   || fileNameLower.endsWith(".docx")
        		   || fileNameLower.endsWith(".jpeg")
        		   || fileNameLower.endsWith(".png")
        		   || fileNameLower.endsWith(".pdf")
        		   || fileNameLower.endsWith(".txt"))) {

            HttpSession msgSession = request.getSession();
            msgSession.setAttribute("msg", "Only JPG, PNG, PDF,TXT files are allowed!");
            msgSession.setAttribute("msgType", "error");

            response.sendRedirect("dashboard.jsp");
            return;
        }
        long size = filePart.getSize(); // bytes

        if (size > 5 * 1024 * 1024) {   // 5MB
            HttpSession msgSession = request.getSession();
            msgSession.setAttribute("msg", "File size must be less than 5MB!");
            msgSession.setAttribute("msgType", "error");

            response.sendRedirect("dashboard.jsp");
            return;
        }


        // Cloud folders
        String cloudA = "C:/cloudA/";
        String cloudB = "C:/cloudB/";
        String cloudC = "C:/cloudC/";

        new File(cloudA).mkdirs();
        new File(cloudB).mkdirs();
        new File(cloudC).mkdirs();

        try {
            // Read file bytes
            // Encrypt
        	InputStream is = filePart.getInputStream();
        	ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        	byte[] temp = new byte[1024];
        	int bytesRead;

        	while ((bytesRead = is.read(temp)) != -1) {
        	    buffer.write(temp, 0, bytesRead);
        	}

        	byte[] fileBytes = buffer.toByteArray();

            byte[] encrypted = AESUtil.encrypt(fileBytes);

            // Split into 3 parts
            int partSize = encrypted.length / 3;

            byte[] part1 = java.util.Arrays.copyOfRange(encrypted, 0, partSize);
            byte[] part2 = java.util.Arrays.copyOfRange(encrypted, partSize, partSize * 2);
            byte[] part3 = java.util.Arrays.copyOfRange(encrypted, partSize * 2, encrypted.length);

            String p1 = cloudA + fileName + ".part1";
            String p2 = cloudB + fileName + ".part2";
            String p3 = cloudC + fileName + ".part3";

            Files.write(Paths.get(p1), part1);
            Files.write(Paths.get(p2), part2);
            Files.write(Paths.get(p3), part3);

            // INSERT METADATA INTO DB
            Connection con = DBConnection.getConnection();
            String sql = "INSERT INTO files "
                    + "(id, filename, filepath, owner, chunk1, chunk2, chunk3) "
                    + "VALUES (file_seq.NEXTVAL, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, fileName);           // filename
            ps.setString(2, "SPLIT_STORAGE");    // filepath (dummy value)
            ps.setString(3, user);               // owner
            ps.setString(4, p1);                 // chunk1
            ps.setString(5, p2);                 // chunk2
            ps.setString(6, p3);                 // chunk3

            ps.executeUpdate();
           con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        session.setAttribute("msg", "File uploaded securely!");
        session.setAttribute("msgType", "success");

        response.sendRedirect("dashboard.jsp");
    }
}
