package com.servlet;

import com.db.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

    	String username = request.getParameter("username").trim();
    	String password = request.getParameter("password").trim();

        System.out.println("USERNAME FROM FORM = [" + username + "]");
        System.out.println("PASSWORD FROM FORM = [" + password + "]");

        try {
            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM users1 WHERE username=? AND password=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("user", username);
                response.sendRedirect("dashboard.jsp");
            } else {
            	 HttpSession session = request.getSession();
            	    session.setAttribute("popupMsg", "Invalid Username or Password");
            	    response.sendRedirect("login.jsp");
           }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
