package com.servlet;

import com.db.DBConnection;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/ForgotPasswordServlet")
public class ForgotPasswordServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                con.prepareStatement("SELECT * FROM users1 WHERE username=?");
            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("resetUser", username);

                response.sendRedirect("resetPassword.jsp");
            } else {
                response.sendRedirect("forgotPassword.jsp?msg=invalid");
           
               }

            con.close();

        } catch (Exception e) {
        	 e.printStackTrace();
        	 response.sendRedirect("forgotPassword.jsp?msg=error");
        	      }
    }
}
