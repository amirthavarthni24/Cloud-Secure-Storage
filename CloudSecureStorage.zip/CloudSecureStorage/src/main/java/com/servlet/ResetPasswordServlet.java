package com.servlet;

import com.db.DBConnection;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/ResetPasswordServlet")
public class ResetPasswordServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("resetUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String user = (String) session.getAttribute("resetUser");
        String newpass = request.getParameter("newpass");
        String conf = request.getParameter("confirmpass");

        // ❌ Password mismatch
        if (!newpass.equals(conf)) {
            response.sendRedirect("resetPassword.jsp?msg=error");
            return;
        }

        // ❌ Password rule check (same as register)
        if (!newpass.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).{8,}$")) {
            response.sendRedirect("resetPassword.jsp?msg=error");
            return;
        }

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps =
                con.prepareStatement("UPDATE users1 SET password=? WHERE username=?");

            ps.setString(1, newpass);
            ps.setString(2, user);
            ps.executeUpdate();

            con.close();

            // ✅ clear reset session
            session.removeAttribute("resetUser");

            // ✅ SUCCESS → modal trigger
            response.sendRedirect("resetPassword.jsp?msg=success");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("resetPassword.jsp?msg=error");
        }
    }
}
