package com.servlet;

import com.db.DBConnection;
import com.security.AESUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;

@WebServlet("/DownloadServlet")
public class DownloadServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String fileName = request.getParameter("file");

        try {
            Connection con = DBConnection.getConnection();

            String sql = "SELECT chunk1, chunk2, chunk3 FROM files WHERE filename=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, fileName);

            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                response.getWriter().println("File not found");
                return;
            }

            // Paths from DB
            String p1 = rs.getString("chunk1");
            String p2 = rs.getString("chunk2");
            String p3 = rs.getString("chunk3");

            // Read encrypted chunks
            byte[] part1 = Files.readAllBytes(Paths.get(p1));
            byte[] part2 = Files.readAllBytes(Paths.get(p2));
            byte[] part3 = Files.readAllBytes(Paths.get(p3));

            // Merge
            ByteArrayOutputStream merged = new ByteArrayOutputStream();
            merged.write(part1);
            merged.write(part2);
            merged.write(part3);

            byte[] encryptedData = merged.toByteArray();

            // Decrypt
            byte[] originalData = AESUtil.decrypt(encryptedData);

            // Download response
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + fileName + "\"");

            OutputStream out = response.getOutputStream();
            out.write(originalData);
            out.flush();
            out.close();

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
