package com.servlet;

import com.db.DBConnection;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.sql.*;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String user = (String) session.getAttribute("user");
        String filename = request.getParameter("file");

        try {
            Connection con = DBConnection.getConnection();

            // 1️⃣ Get chunk paths
            String selectSql =
                "SELECT chunk1, chunk2, chunk3 FROM files WHERE filename=? AND owner=?";
            PreparedStatement ps1 = con.prepareStatement(selectSql);
            ps1.setString(1, filename);
            ps1.setString(2, user);

            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {
                String c1 = rs.getString("chunk1");
                String c2 = rs.getString("chunk2");
                String c3 = rs.getString("chunk3");

                // 2️⃣ Delete cloud files
                deleteFile(c1);
                deleteFile(c2);
                deleteFile(c3);
            }

            // 3️⃣ Delete DB record
            String deleteSql =
                "DELETE FROM files WHERE filename=? AND owner=?";
            PreparedStatement ps2 = con.prepareStatement(deleteSql);
            ps2.setString(1, filename);
            ps2.setString(2, user);
            ps2.executeUpdate();

            con.close();
            HttpSession msgSession = request.getSession();
            msgSession.setAttribute("msg", "File deleted successfully!");
            msgSession.setAttribute("msgType", "success");


        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("dashboard.jsp");
    }

    private void deleteFile(String path) {
        if (path != null) {
            File f = new File(path);
            if (f.exists()) {
                f.delete();
            }
        }
    }
}
