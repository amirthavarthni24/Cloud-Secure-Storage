<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(to right, #141e30, #243b55);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }

        .login-box {
            background: rgba(0, 0, 0, 0.6);
            padding: 40px;
            width: 380px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.7);
        }

        h2 {
            color: #00e6e6;
            margin-bottom: 20px;
        }

        input[type=text], input[type=email], input[type=password] {
            width: 95%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 20px;
            border: none;
            outline: none;
        }

        .password-box {
            position: relative;
        }

        .password-box span {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #000;
            font-size: 14px;
        }

        .btn {
            width: 95%;
            padding: 12px;
            margin-top: 15px;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            cursor: pointer;
            background: #00c6ff;
            color: #000;
        }

        .btn:hover {
            background: #00a3cc;
        }

        .back {
            margin-top: 15px;
            font-size: 13px;
        }

        .back a {
            color: #7cff00;
            text-decoration: none;
        }

        .note {
            font-size: 12px;
            color: #ccc;
            margin-top: 8px;
            text-align: left;
        }
    </style>

    <script>
        function togglePassword() {
            var pwd = document.getElementById("password");
            if (pwd.type === "password") {
                pwd.type = "text";
            } else {
                pwd.type = "password";
            }
        }

        function validatePassword() {
            var pwd = document.getElementById("password").value;
            var pattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;

            if (!pattern.test(pwd)) {
                alert(
                    "Password must contain:\n" +
                    "- Minimum 8 characters\n" +
                    "- One uppercase letter\n" +
                    "- One lowercase letter\n" +
                    "- One number\n" +
                    "- One special character"
                );
                return false;
            }
            return true;
        }
    </script>
</head>

<body>

<div class="login-box">
    <h2>User Registration</h2>

    <form action="RegisterServlet" method="post" onsubmit="return validatePassword()">

        <input type="text" name="username" placeholder="Username" required>

        <input type="email" name="email" placeholder="Email Address" required>

        <div class="password-box">
            <input type="password" id="password" name="password" placeholder="Password" required>
            <span onclick="togglePassword()">👁️</span>
        </div>

        <div class="note">
            Password must include uppercase, lowercase, number & special character
        </div>

        <input type="submit" value="Register" class="btn">
    </form>

    <div class="back">
        Already have an account? <a href="login.jsp">Login here</a><br><br>
        <a href="index.jsp">Back to Home</a>
    </div>
</div>

</body>
</html>
