<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page session="true" %>

<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
<title>Upload File</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #141e30, #243b55);
    color: white;

    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
}

/* Main card */
.card {
    width: 420px;
    background: rgba(255,255,255,0.1);
    padding: 30px;
    border-radius: 10px;
    text-align: center;
}

/* Heading */
.card h2 {
    margin-bottom: 20px;
    font-size: 26px;
}

/* File input */
input[type="file"] {
    margin: 15px 0;
    color: white;
}

/* Upload button */
input[type="submit"] {
    background: #00e6e6;
    color: #000;
    border: none;
    padding: 8px 18px;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
}

input[type="submit"]:hover {
    background: #00cccc;
}

/* Back link */
.back-link {
    display: inline-block;
    margin-top: 15px;
    color: #00e6e6;
    text-decoration: none;
}
/* Center file input */
.file-center {
    display: flex;
    justify-content: center;
}

/* Make file chooser neat */
input[type="file"] {
    background: white;
    color: black;
    padding: 4px;
    border-radius: 4px;
}

</style>

</head>

<body>

<div class="card">
    <h2>Upload File</h2>
	<form action="UploadServlet"
      method="post"
      enctype="multipart/form-data">

    <div class="file-center">
        <input type="file" name="file" required>
    </div>

    <br>
    <input type="submit" value="Upload File">
</form>
	
    

    <a class="back-link" href="dashboard.jsp">Back to Dashboard</a>
</div>

</body>
</html>
