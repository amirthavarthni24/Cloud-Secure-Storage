<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<%
if(session.getAttribute("resetUser")==null){
    response.sendRedirect("login.jsp");
    return;
}
String msg = request.getParameter("msg");
%>

<!DOCTYPE html>
<html>
<head>
<title>Reset Password</title>

<style>
body{
    margin:0;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(to right,#141e30,#243b55);
    font-family:Arial;
}
.card{
    background:rgba(0,0,0,0.6);
    padding:40px;
    width:400px;
    border-radius:15px;
    text-align:center;
    color:white;
}
h2{ color:#00e6e6; }

.input-box{
    position:relative;
}
.input-box input{
    width:100%;
    padding:14px;
    margin:12px 0;
    border:none;
    border-radius:25px;
}
.eye{
    position:absolute;
    right:18px;
    top:50%;
    transform:translateY(-50%);
    cursor:pointer;
    font-size:18px;
}
button{
    width:80%;
    padding:14px;
    background:#00cfff;
    border:none;
    border-radius:25px;
    font-size:16px;
    cursor:pointer;
}

/* modal */
.modal{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0.6);
}
.modal-box{
    background:#1f2a3a;
    color:white;
    width:350px;
    padding:25px;
    border-radius:10px;
    text-align:center;
    margin:15% auto;
}
.password-box{
    position: relative;
    width: 100%;
    margin: 15px 0;
}

.password-box input{
    width: 80%;
    padding: 14px 45px 14px 18px;
    border-radius: 30px;
    border: none;
    outline: none;
    font-size: 15px;
}

.eye{
    position: absolute;
    right: 18px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    font-size: 18px;
    color: #555;
}


</style>
</head>

<body>

<div class="card">
    <h2>Reset Password</h2>

    <form action="ResetPasswordServlet" method="post">
        <div class="password-box">
    <input type="password" id="newpass" name="newpass" placeholder="New Password" required>
    <span class="eye" onclick="toggle('newpass')">👁</span>
</div>

<div class="password-box">
    <input type="password" id="confirmpass" name="confirmpass" placeholder="Confirm Password" required>
    <span class="eye" onclick="toggle('confirmpass')">👁</span>
</div>
        

        <button type="submit">Update Password</button>
    </form>
</div>

<!-- POPUP -->
<div id="msgModal" class="modal">
  <div class="modal-box">
    <p id="msgText"></p>
    <button onclick="goLogin()">OK</button>
  </div>
</div>

<script>
function toggle(id){
    let f=document.getElementById(id);
    f.type = (f.type==="password") ? "text" : "password";
}

function goLogin(){
    window.location.href="login.jsp";
}

// 🔥 MODAL TRIGGER
<% if("success".equals(msg)){ %>
document.getElementById("msgText").innerText="Password updated successfully";
document.getElementById("msgModal").style.display="block";
<% } else if("error".equals(msg)){ %>
document.getElementById("msgText").innerText="Password mismatch / invalid password";
document.getElementById("msgModal").style.display="block";
<% } %>
</script>

</body>
</html>
