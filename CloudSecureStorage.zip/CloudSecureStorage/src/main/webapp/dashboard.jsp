<%@ page import="java.sql.*" %>
<%@ page import="com.db.DBConnection" %>
<%@ page session="true" %>

<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    String user = (String) session.getAttribute("user");
%>

<html>
<head>
<title>Dashboard</title>
<style>
body {
    font-family: Arial;
    background: linear-gradient(to right, #141e30, #243b55);
    color: white;

    display: flex;
    justify-content: center;  
    align-items: center;       
    min-height: 100vh;
    margin: 0;
}

.card {
    width: 600px;
    margin: 80px auto;
    background: rgba(255,255,255,0.1);
    padding: 30px;
    border-radius: 10px;
}
table {
    width: 100%;
    border-collapse: collapse;
}
th, td {
    padding: 10px;
    border-bottom: 1px solid #aaa;
}
a {
    color: #00e6e6;
    text-decoration: none;
}
.welcome-text {
    text-align: center;
    font-size: 28px;
    font-weight: 700;
    letter-spacing: 1px;
    margin-bottom: 5px;
}


.container {
    display: flex;
    justify-content: center;
    align-items: flex-start;   /* 🔥 CHANGE */
    padding-top: 40px;         /* 🔥 ADD */
    min-height: 100vh;
}
/* Reduce top spacing */
.card {
    width: 600px;
    background: rgba(255,255,255,0.1);
    padding: 30px;
    border-radius: 10px;
}
.card a {
    margin: 0 6px;
}
.divider {
    color: #aaa;
    margin: 0 6px;
}


h3 {
    margin-top: 20px;
    margin-bottom: 10px;
}


.modal {
    display: none;              
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    justify-content: center;
    align-items: center;
    z-index: 9999;
}

.modal-box {
    background: #1f2a3a;
    padding: 25px;
    border-radius: 8px;
    width: 360px;
    text-align: center;
}

.modal-box h3 {
    margin-bottom: 10px;
}

.modal-actions button {
    margin: 10px;
    padding: 6px 16px;
    border: none;
    cursor: pointer;
}
.msg {
    text-align: center;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    font-size: 14px;
}

.msg.success {
    background-color: rgba(0, 255, 150, 0.2);
    color: #00ffb3;
}

.msg.error {
    background-color: rgba(255, 0, 0, 0.2);
    color: #ff8080;
}

</style>
</head>

<body>

<div class="card">
    <h2 class="welcome-text">Welcome <%= user %></h2>
    <%
    String msg = (String) session.getAttribute("msg");
    String msgType = (String) session.getAttribute("msgType");

    if (msg != null) {
%>
    <div style="
        text-align:center;
        margin:15px 0;
        padding:10px;
        border-radius:6px;
        color:white;
        background-color: <%= "error".equals(msgType) ? "#e74c3c" : "#2ecc71" %>;
    ">
        <%= msg %>
    </div>
<%
        session.removeAttribute("msg");
        session.removeAttribute("msgType");
    }
%>
    
	<div style="text-align:center; margin-bottom:20px;">
    <a href="upload.jsp">Upload File</a> |
    <a href="logout.jsp">Logout</a>
</div>

    <h3>Your Files</h3>

    <table>
        <tr>
            <th>File Name</th>
            <th>Action</th>
        </tr>

<%
    try {
        Connection con = DBConnection.getConnection();
        String sql = "SELECT filename FROM files WHERE owner=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, user);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            String fname = rs.getString("filename");
%>
        <tr>
            <td><%= fname %></td>
         <td>
   		<a href="DownloadServlet?file=<%= rs.getString("filename") %>">Download</a>
		<span class="divider"> | </span>
		<a href="javascript:void(0)" onclick="confirmDelete('<%= fname %>')">Delete</a>
		
</td>
         
        </tr>
<%
        }
        con.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
%>
</table>
<!-- Custom Delete Modal -->
<div id="deleteModal" class="modal">
  <div class="modal-box">
    <h3>Confirm Delete</h3>
    <p>Are you sure you want to permanently delete this file?</p>

    <div class="modal-actions">
      <button onclick="proceedDelete()">Delete</button>
      <button onclick="closeModal()">Cancel</button>
    </div>
  </div>
</div>

</div>

</body>
<script>
let deleteFile = "";

function confirmDelete(file) {
    deleteFile = file;
    document.getElementById("deleteModal").style.display = "flex";
}

function closeModal() {
    document.getElementById("deleteModal").style.display = "none";
}

function proceedDelete() {
    window.location.href =
        "DeleteServlet?file=" + encodeURIComponent(deleteFile);
}
</script>


</html>
