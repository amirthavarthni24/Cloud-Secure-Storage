<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.sql.Connection" %>
<%@ page import="com.db.DBConnection" %>

<!DOCTYPE html>
<html>
<head>
    <title>DB Test</title>
</head>
<body>

<h2>Database Connection Test</h2>

<%
    Connection con = DBConnection.getConnection();

    if (con != null) {
        out.println("<h3 style='color:green;'>DB Connection SUCCESS</h3>");
    } else {
        out.println("<h3 style='color:red;'>DB Connection FAILED</h3>");
    }
%>

</body>
</html>
    