<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(to right, #141e30, #243b55);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }

        .login-box {
            background: rgba(0, 0, 0, 0.6);
            padding: 50px;
            width: 380px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.7);
        }

        h2 {
            color: #00e6e6;
            margin-bottom: 20px;
        }

        input[type=text], input[type=password] {
            width: 95%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 20px;
            border: none;
            outline: none;
        }

        .password-box {
            position: relative;
        }

        .password-box span {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #000;
            font-size: 14px;
        }

        .btn {
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            cursor: pointer;
            background: #00c6ff;
            color: #000;
        }

        .btn:hover {
            background: #00a3cc;
        }

        .back {
            margin-top: 15px;
            font-size: 13px;
        }

        .back a {
            color: #7cff00;
            text-decoration: none;
        }
        .modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    justify-content: center;
    align-items: center;
}

.modal-box {
    background: #1f2a3a;
    padding: 25px;
    border-radius: 8px;
    width: 350px;
    text-align: center;
    color: white;
}

.modal-actions button {
    margin-top: 15px;
    padding: 8px 20px;
    background: #00e6e6;
    border: none;
    cursor: pointer;
    border-radius: 4px;
}
  .modal{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0.6);
}
.modal-box{
    background:#1f2a3a;
    color:white;
    width:350px;
    padding:25px;
    border-radius:10px;
    text-align:center;
    margin:15% auto;
}
.modal-box button{
    margin-top:15px;
    padding:10px 25px;
    border:none;
    border-radius:20px;
    background:#00cfff;
    cursor:pointer;
}
        
    </style>

    <script>
        function togglePassword() {
            var pwd = document.getElementById("password");
            var eye = document.getElementById("eye");

            if (pwd.type === "password") {
                pwd.type = "text";
           
            } else {
                pwd.type = "password";
                eye.innerHTML = "👁️";
            }
        }
    </script>
</head>

<body>

<div class="login-box">
    <h2>User Login</h2>

  		<form action="LoginServlet" method="post">
  		
        <input type="text" name="username" placeholder="Username" required>

        <div class="password-box">
            <input type="password" id="password" name="password" placeholder="Password" required>
            <span id="eye" onclick="togglePassword()">👁️</span>
        </div>

        <input type="submit" value="Login" class="btn">
    </form>

    <div class="back">
        New user? <a href="register.jsp">Register here</a><br><br>
        <a href="forgotPassword.jsp" style="color:#00e6e6;">Forgot Password</a>
        
    </div>
</div>
	<!-- Logout Success Modal -->
<div id="logoutModal" class="modal">
  <div class="modal-box">
    <h3>Logged Out</h3>
    <p>Logout successfully</p>

    <div class="modal-actions">
      <button onclick="closeLogoutModal()">OK</button>
    </div>
  </div>
</div>
<div id="errorModal" class="modal">
  <div class="modal-box">
    <p id="modalText"></p>
    <button onclick="closeModal()">OK</button>
  </div>
</div>

	
</body>
<script>
function closeLogoutModal() {
    document.getElementById("logoutModal").style.display = "none";
}

// Show logout popup only when redirected from logout.jsp
window.onload = function () {
    const params = new URLSearchParams(window.location.search);
    if (params.get("logout") === "success") {
        document.getElementById("logoutModal").style.display = "flex";
    }
};
</script>
<script>
function closeModal(){
    document.getElementById("errorModal").style.display="none";
}
</script>

<%
String msg = (String)session.getAttribute("popupMsg");
if(msg != null){
%>
<script>
document.getElementById("modalText").innerText = "<%=msg%>";
document.getElementById("errorModal").style.display = "block";
</script>
<%
session.removeAttribute("popupMsg"); // VERY IMPORTANT
}
%>

</html>
    