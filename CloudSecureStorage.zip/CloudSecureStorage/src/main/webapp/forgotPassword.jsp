<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<title>Forgot Password</title>
<style>
body{
    margin:0;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(to right,#141e30,#243b55);
    font-family:Arial;
}
.card{
    teach: rgba(0,0,0,0.6);
    background:rgba(0,0,0,0.6);
    padding:40px;
    width:380px;
    border-radius:12px;
    text-align:center;
    color:white;
}
.card h2{ color:#00e6e6; margin-bottom:20px; }
input{
    width:100%;
    padding:12px;
    margin:12px 0;
    border:none;
    border-radius:25px;
}
button{
    width:100%;
    padding:12px;
    background:#00cfff;
    border:none;
    border-radius:25px;
    font-size:16px;
    cursor:pointer;
}
a{ color:#00e6e6; text-decoration:none; font-size:14px; }

/* modal */
.modal{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0.6);
}
.modal-box{
    background:#1f2a3a;
    color:white;
    width:350px;
    padding:25px;
    border-radius:10px;
    text-align:center;
    margin:15% auto;
}
.modal-box button{
    width:100px;
    margin-top:15px;
}
</style>
</head>
<body>

<div class="card">
    <h2>Forgot Password</h2>
    <form action="ForgotPasswordServlet" method="post">
        <input type="text" name="username" placeholder="Enter Username" required>
        <button type="submit">Verify User</button>
    </form>
    <br>
    
    <a href="login.jsp">Back to Login</a>
</div>

<!-- Error Modal -->
<div id="errorModal" class="modal">
  <div class="modal-box">
    <p>User not found</p>
    <button onclick="closeModal()">OK</button>
  </div>
</div>

<script>
function closeModal(){
    document.getElementById("errorModal").style.display="none";
}
<% if("invalid".equals(request.getParameter("msg"))){ %>
document.getElementById("errorModal").style.display="block";
document.querySelector(".modal-box p").innerText="Invalid Username";
<% } %>

<% if("error".equals(request.getParameter("msg"))){ %>
document.getElementById("errorModal").style.display="block";
document.querySelector(".modal-box p").innerText="Something went wrong";
<% } %>

</script>

</body>
</html>
