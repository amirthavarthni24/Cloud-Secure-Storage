<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Cloud Secure Storage</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(to right, #141e30, #243b55);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }

        .container {
            background: rgba(0, 0, 0, 0.6);
            padding: 40px;
            width: 400px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.7);
        }

        h1 {
            margin-bottom: 10px;
            color: #00e6e6;
        }

        p {
            font-size: 14px;
            margin-bottom: 25px;
            color: #ccc;
        }

        .btn {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .login-btn {
            background: #00c6ff;
            color: #000;
        }

        .login-btn:hover {
            background: #00a3cc;
        }

        .register-btn {
            background: #7cff00;
            color: #000;
        }

        .register-btn:hover {
            background: #63cc00;
        }

        footer {
            margin-top: 20px;
            font-size: 12px;
            color: #aaa;
        }
    </style>
</head>

<body>

<div class="container">
    <h1>Cloud Secure Storage</h1>
    <p>Secure Big Data Storage using Cloud of Clouds</p>

    <a href="login.jsp">
        <button class="btn login-btn">Login</button>
    </a>

    <a href="register.jsp">
        <button class="btn register-btn">Register </button>
    </a>

    <footer>
        © 2025 Cloud Secure Storage Project
    </footer>
</div>

</body>
</html>
    