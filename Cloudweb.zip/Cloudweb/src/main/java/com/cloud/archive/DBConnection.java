package com.cloud.archive;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() {
        Connection con = null;
        try {
            // Correct Oracle Driver
            Class.forName("oracle.jdbc.OracleDriver");

            // IMPORTANT: SERVICE NAME = SYS$USERS
            con = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521/SYS$USERS",
                "clouduser",
                "cloud123"
            );

            System.out.println("DB CONNECTED SUCCESSFULLY");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
}
