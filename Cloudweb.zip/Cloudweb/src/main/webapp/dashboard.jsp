<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>

<h1>Welcome to Cloud Archive System</h1>

<p>
    Logged in as: <b><%= session.getAttribute("user") %></b>
</p>

<ul>
    <li>Secure Login</li>
    <li>User Authentication</li>
    <li>Oracle Database Integration</li>
    <li>Session Management</li>
</ul>

<a href="logout.jsp">Logout</a>

<a href="archive.jsp">Go to Archive</a>


</body>
</html>
