<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<title>User Login</title>

<style>
body{
    margin:0;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(135deg, #667eea, #764ba2);
    font-family: Arial, sans-serif;
}
.box{
    background:#fff;
    width:400px;
    padding:40px;
    border-radius:15px;
    box-shadow:0 15px 40px rgba(0,0,0,0.3);
    text-align:center;
}
input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:6px;
    border:1px solid #ccc;
}
button{
    width:100%;
    padding:12px;
    background:#667eea;
    border:none;
    color:white;
    font-size:18px;
    border-radius:8px;
}
.error{
    color:red;
    margin-top:10px;
}
</style>
</head>

<body>

<div class="box">
<h2>User Login</h2>

<form method="post">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
</form>

<%
    if("POST".equalsIgnoreCase(request.getMethod())){
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // TEMPORARY AUTHENTICATION
        if(email.equals("test@gmail.com") && password.equals("test123")){
            session.setAttribute("user", email);
            response.sendRedirect("dashboard.jsp");
        } else {
%>
            <div class="error">Invalid Email or Password</div>
<%
        }
    }
%>

</div>

</body>
</html>
