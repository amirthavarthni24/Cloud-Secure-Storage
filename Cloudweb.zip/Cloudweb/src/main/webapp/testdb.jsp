<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="com.cloud.archive.DBConnection" %>

<%
    Connection con = DBConnection.getConnection();
    if(con != null){
        out.println("DB CONNECTED ✅");
    } else {
        out.println("DB CONNECTION FAILED ❌");
    }
%>
    