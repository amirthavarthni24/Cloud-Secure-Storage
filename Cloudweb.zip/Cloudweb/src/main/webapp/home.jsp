<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<html>
<head>
<title>Home</title>
</head>
<body>

<h2>Login Successful ✅</h2>
<p>Welcome to Cloud Archive System</p>

</body>
</html>
    