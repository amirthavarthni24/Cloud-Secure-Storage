<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<h2>Cloud Archive</h2>
<p>This module is used to store and manage archived data securely.</p>

<a href="dashboard.jsp">Back to Dashboard</a>
    