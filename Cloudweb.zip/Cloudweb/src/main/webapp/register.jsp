<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Register</title>

<style>
    body{
        margin:0;
        height:100vh;
        display:flex;
        justify-content:center;
        align-items:center;
        background: linear-gradient(135deg, #667eea, #764ba2);
        font-family: Arial, sans-serif;
    }

    .box{
        background:#fff;
        width:400px;
        padding:40px;
        border-radius:15px;
        box-shadow:0 15px 40px rgba(0,0,0,0.3);
        text-align:center;
    }

    h2{
        margin-bottom:25px;
        color:#333;
    }

    input{
        width:100%;
        padding:12px;
        margin:10px 0;
        border-radius:6px;
        border:1px solid #ccc;
        font-size:16px;
    }

    button{
        width:100%;
        padding:12px;
        background:#764ba2;
        border:none;
        color:white;
        font-size:18px;
        border-radius:8px;
        cursor:pointer;
    }

    button:hover{
        opacity:0.9;
    }

    a{
        display:block;
        margin-top:15px;
        text-decoration:none;
        color:#667eea;
    }
    .password-box {
    position: relative;
    width: 91%;
}

.password-box input {
    width: 100%;
    padding: 14px 45px 14px 15px;
    font-size: 16px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

.toggle-eye {
    position: absolute;
    left:400px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    font-size: 18px;
}

#passwordMsg {
    display: block;
    margin-top: 8px;
    font-size: 14px;
}
    
</style>

</head>
<body>

<div class="box">
    <h2>Register</h2>

    <form action="RegisterServlet" method="post" onsubmit="return validatePassword()">
    
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
		<div class="password-box">
    	<input 
        type="password" 
        id="password" 
        name="password" 
        placeholder="Password"
        required>
    	<span class="toggle-eye" onclick="togglePassword()">👁</span>
		</div>

		<small id="passwordMsg"></small>
		
        

        <button type="submit">Create Account</button>
    </form>

    <a href="login.jsp">Already have an account? Login</a>
    <script>
    
    function togglePassword() {
        const pwd = document.getElementById("password");
        pwd.type = pwd.type === "password" ? "text" : "password";
    }

    function validatePassword() {
        let pwd = document.getElementById("password").value;
        let msg = document.getElementById("passwordMsg");

        let pattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;

        if (!pattern.test(pwd)) {
            msg.style.color = "red";
            msg.innerHTML =
              "Password must have minimum 8 characters, 1 uppercase letter, 1 number and 1 special character";
            return false;   // ❗ form submit STOP
        } else {
            msg.innerHTML = "";
            return true;    // ✅ form submit ALLOW
        }
    }


</script>
</div>

</body>
</html>
