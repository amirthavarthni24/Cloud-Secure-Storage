<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Cloud Archive System</title>

<style>
body {
    margin: 0;
    height: 100vh;
    background: linear-gradient(to right, #667eea, #764ba2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: Arial, sans-serif;
}

.container {
    background: white;
    width: 650px;
    padding: 60px;
    text-align: center;
    border-radius: 18px;
    box-shadow: 0 20px 45px rgba(0,0,0,0.3);
}

h1 {
    font-size: 34px;
    color: #333;
    margin-bottom: 15px;
}

p {
    font-size: 18px;
    color: #555;
    margin-bottom: 40px;
}

.buttons {
    display: flex;
    justify-content: center;
    gap: 30px;
}

.buttons a {
    text-decoration: none;
}

button {
    padding: 15px 40px;
    font-size: 18px;
    border: none;
    border-radius: 8px;
    color: white;
    cursor: pointer;
}

.login-btn {
    background: #667eea;
}

.register-btn {
    background: #764ba2;
}

button:hover {
    transform: scale(1.08);
    transition: 0.3s;
}
</style>

</head>
<body>

<div class="container">
    <h1>Cloud Based Archive System</h1>
    <p>Secure storage and sharing of data using Cloud-of-Clouds</p>

    <div class="buttons">
        <a href="login.jsp">
            <button class="login-btn">Login</button>
        </a>

        <a href="register.jsp">
            <button class="register-btn">Register</button>
        </a>
    </div>
</div>

</body>
</html>

